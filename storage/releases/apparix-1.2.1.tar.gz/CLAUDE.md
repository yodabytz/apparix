# Apparix E-Commerce Platform - Development Notes

## Site Overview
This is a custom PHP MVC e-commerce platform. It was cloned from Lily's Pad Studio and rebranded.

## Architecture

### Directory Structure
```
/var/www/apparix.app/
├── app/
│   ├── Controllers/       # Route handlers
│   │   ├── Admin/         # Admin panel controllers
│   │   └── *.php          # Frontend controllers
│   ├── Models/            # Database models
│   ├── Views/             # PHP templates
│   │   ├── layouts/       # Main layout templates (main.php, admin.php)
│   │   ├── admin/         # Admin panel views
│   │   └── */             # Frontend views by section
│   ├── Core/              # Framework core classes
│   └── Helpers/           # Helper functions
├── public/                # Web root (document root)
│   ├── index.php          # Front controller / router
│   ├── assets/
│   │   ├── css/           # Stylesheets
│   │   ├── js/            # JavaScript
│   │   └── images/        # Static images & product images
│   └── *.php              # Public PHP files (404.php, etc.)
├── storage/
│   ├── logs/              # Application logs
│   └── sessions/          # PHP sessions
├── vendor/                # Composer dependencies
├── cron/                  # Cron job scripts
├── newsletter/            # Newsletter templates
└── .env                   # Environment configuration
```

### Database
- **Database**: `apparix_ecommerce`
- **User**: `apparix`
- **Password**: `apparix_secure_2024`

Key tables:
- `products`, `product_variants`, `product_images`, `product_categories`
- `categories`
- `orders`, `order_items`
- `users`, `admin_users`
- `cart_items`
- `shipping_origins`, `shipping_zones`, `shipping_rates`
- `coupons`
- `reviews`

### Configuration
- `.env` file contains all configuration (DB, Stripe, email, reCAPTCHA, etc.)
- `APP_NAME` in .env controls site name
- `appName()` helper function returns the site name

### Key Files

**Routing**: `/public/index.php` - All routes defined here

**Layouts**:
- `/app/Views/layouts/main.php` - Frontend layout
- `/app/Views/layouts/admin.php` - Admin panel layout

**CSS/JS Version Cache Busting**:
- CSS: `/app/Views/layouts/main.php` line ~63 (`main.css?v=XX`)
- JS: `/app/Views/layouts/main.php` line ~301 (`main.js?v=XX`)

**Controllers**:
- `HomeController` - Homepage
- `ProductController` - Product listing/detail
- `CartController` - Shopping cart
- `CheckoutController` - Checkout process
- `Admin/ProductController` - Product management
- `Admin/OrderController` - Order management

### Security
- ModSecurity WAF enabled
- SecuNX IP blocklist (`/etc/nginx/secuNX/`)
- CSRF protection via `csrfField()` helper
- reCAPTCHA v3 on forms
- Argon2id password hashing

### Nginx Config
Location: `/etc/nginx/sites-available/apparix.app`

### SSL Certificate
Let's Encrypt certificate at `/etc/letsencrypt/live/apparix.app/`

## Common Tasks

### Adding a Country to Shipping
Edit `/app/Views/admin/shipping/index.php` - update both country dropdowns

### Category-Specific Product Ordering
Products can be ordered per-category via `product_categories.sort_order`

### Admin Login
URL: `/admin/login`
Uses `admin_users` table with `password_hash` column (Argon2id)

## Mobile Pinch-to-Zoom Fix (Lightbox)

### JavaScript Requirements:
1. Attach touch events to the **lightbox container** (not the image)
2. Use `{ passive: false, capture: true }` on touchstart and touchmove
3. Call `e.preventDefault()` and `e.stopPropagation()`
4. Use `img.style.setProperty('transform', 'scale(' + scale + ')', 'important')`

### CSS Requirements:
1. `touch-action: none` on the lightbox content container
2. `overflow: visible` on the content container
3. `will-change: transform` on the image
4. `transform-origin: center center` on the image

### Key Files:
- `/public/assets/js/main.js` - createImageLightbox() function
- `/public/assets/css/main.css` - .image-lightbox styles

## Things to Configure
- Stripe API keys in `.env`
- reCAPTCHA keys in `.env`
- Google Analytics ID in layout (currently has lilyspad's ID)
- Email settings in `.env`
- Ntfy notification topic in `.env`
- AfterShip API key in `.env`
